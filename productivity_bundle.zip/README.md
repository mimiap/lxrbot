# Productivity Bundle (EN)

This bundle includes 3 printable PDFs:

1. **Weekly Planner** – plan your week in a minimalist layout.
2. **Budget Tracker** – monthly income/expense sheet.
3. **Habit Tracker** – 30-day tracker with checkboxes.

## How to Sell via Telegram Bot

1. Upload these files to your GitHub repository or a private file host.
2. In your Telegram bot code, after successful PayPal payment, send the user a download link to these files.
   - Example: provide a link to your server's `/downloads/productivity_bundle.zip`.
3. Suggested price: **5–8 EUR**.

Enjoy and good luck with your digital product sales!
